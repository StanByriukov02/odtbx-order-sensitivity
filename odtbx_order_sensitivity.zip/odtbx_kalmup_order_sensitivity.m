% ODTBX order-sensitivity demo using kalmup (single precision)
% Goal: show that finite-precision Kalman updates can be order-sensitive when:
% - you process multiple measurements sequentially (different orders), and/or
% - you compare batch-vector update vs sequential-scalar updates,
% on a poorly-conditioned covariance boundary.
%
% This is intentionally reproducible (fixed RNG seed) and uses ODTBX `kalmup`.

addpath('C:/Users/dammi/third_party/odtbx-mirror/odtbx/ODTBX_Source');

format long g;

% Fixed RNG seed for reproducibility
rand('seed', 123);
randn('seed', 123);

% State and measurement sizes
n = 8;
m = 8;

% Construct a starting state with extreme dynamic range (single precision)
x0 = single([1.0e10; 1.0; -1.0e10; 1.0; 1.0e5; -1.0e5; 1.0e-2; -1.0e-2]);

% Build a strongly-conditioned covariance matrix in single precision:
% P0 = D * (A'*A) * D, with large/small scales in D.
A = randn(n, n);
baseP = A' * A;
D = diag(single([1.0e5, 1.0, 1.0e5, 1.0, 1.0e2, 1.0e2, 1.0e-2, 1.0e-2]));
P0 = single(D * baseP * D);
P0 = single((P0 + P0') / 2);

% Linear measurement model h = H*x, y = h + v
Hfull = single(randn(m, n));
% Make first two rows near-collinear (sensitivity amplifier)
Hfull(2, :) = Hfull(1, :) + single(1.0e-7) * Hfull(2, :);

% Measurement noise: small, but not identical per measurement
Rdiag = single(abs(1.0e-6 * (1.0 + 0.1 * randn(m, 1))) + 1.0e-9);
Rfull = single(diag(Rdiag));

% True state differs slightly so the innovation is non-zero
x_true = x0;
x_true(2) = x_true(2) + single(1.0e-3);
x_true(4) = x_true(4) + single(2.0e-3);
x_true(7) = x_true(7) + single(5.0e-4);
yfull = single(Hfull * x_true);

% Datfun required by ominusc/kalmup: [h,H,R] = datfun(t,x,datarg)
% Supports:
% - datarg.idx == 0  -> vector measurement (all rows)
% - datarg.idx >= 1  -> scalar measurement (one row)
function [h,H,R] = linmeas_single(t, x, datarg) %#ok<INUSD>
  if ~isfield(datarg, 'idx')
    idx = 0;
  else
    idx = datarg.idx;
  end
  if idx == 0
    H = datarg.H;
    h = single(H * single(x));
    R = datarg.R;
  else
    Hrow = datarg.H(idx, :);
    h = single(Hrow * single(x));
    H = Hrow;
    R = single(datarg.R(idx, idx));
  end
end

function hx = single_hex_words(x)
  % Return uint32 words as hex strings for each single element
  x = single(x);
  u = typecast(x, 'uint32');
  hx = arrayfun(@(v) sprintf('%08x', v), u, 'UniformOutput', false);
end

% Sequential update helper: apply kalmup to one measurement index at a time
function [x,P] = seq_update(order, x, P, yfull, Hfull, Rfull)
  t = 0;
  for k = 1:numel(order)
    idx = order(k);
    datarg = struct('idx', idx, 'H', Hfull, 'R', Rfull);
    yk = single(yfull(idx));
    % ODTBX editmeas expects eflags/eratios to be sized for the measurement.
    % Use eflag=2 (force accept) + eratio=Inf to avoid editing affecting the demo.
    [x, P] = kalmup(@linmeas_single, t, single(x), single(P), yk, [], 2, Inf, datarg);
    x = single(x);
    P = single(P);
  end
end

order_A = 1:m;
order_B = [3 1 4 2 5 6 7 8];

% Compare:
% - batch vector update (one call)
% - sequential scalar updates (two different orders)
eflags_vec = 2 * ones(m, 1);
eratios_vec = Inf * ones(m, 1);

[xBatch, PBatch] = kalmup(@linmeas_single, 0, x0, P0, yfull, [], eflags_vec, eratios_vec, struct('idx', 0, 'H', Hfull, 'R', Rfull));
[xSeqA, PSeqA] = seq_update(order_A, x0, P0, yfull, Hfull, Rfull);
[xSeqB, PSeqB] = seq_update(order_B, x0, P0, yfull, Hfull, Rfull);

disp('--- ODTBX kalmup: order sensitivity (single precision) ---');
disp(['order_A = ' mat2str(order_A)]);
disp(['order_B = ' mat2str(order_B)]);

hexBatch = single_hex_words(xBatch);
hexSeqA = single_hex_words(xSeqA);
hexSeqB = single_hex_words(xSeqB);

disp('xBatch hex (single words):'); disp(hexBatch');
disp('xSeqA  hex (single words):'); disp(hexSeqA');
disp('xSeqB  hex (single words):'); disp(hexSeqB');

same_A = isequal(hexBatch, hexSeqA);
same_B = isequal(hexBatch, hexSeqB);
same_AB = isequal(hexSeqA, hexSeqB);
disp(['bit_identical(batch vs seqA) = ' mat2str(same_A)]);
disp(['bit_identical(batch vs seqB) = ' mat2str(same_B)]);
disp(['bit_identical(seqA vs seqB)  = ' mat2str(same_AB)]);

